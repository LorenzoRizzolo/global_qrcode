import{a as t}from"../chunks/entry.BZ6fcjyu.js";export{t as start};
