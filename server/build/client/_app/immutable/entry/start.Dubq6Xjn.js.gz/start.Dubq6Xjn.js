import{a as t}from"../chunks/entry.DdkiE7so.js";export{t as start};
