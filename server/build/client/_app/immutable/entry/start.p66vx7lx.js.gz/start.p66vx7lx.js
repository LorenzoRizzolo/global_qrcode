import{a as t}from"../chunks/entry.DqBNM3ZP.js";export{t as start};
