import{a as t}from"../chunks/entry.DpJcbMEN.js";export{t as start};
