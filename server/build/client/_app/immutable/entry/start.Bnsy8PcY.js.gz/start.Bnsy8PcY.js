import{a as t}from"../chunks/entry.qn4RBUdn.js";export{t as start};
