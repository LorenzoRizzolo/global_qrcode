import{a as t}from"../chunks/entry.BS8P3x6F.js";export{t as start};
