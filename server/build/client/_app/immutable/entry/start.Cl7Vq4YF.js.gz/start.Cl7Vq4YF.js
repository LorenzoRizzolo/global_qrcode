import{a as t}from"../chunks/entry.BegpIEOl.js";export{t as start};
