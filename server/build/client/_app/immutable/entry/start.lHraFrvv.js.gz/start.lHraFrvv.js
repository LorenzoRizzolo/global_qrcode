import{a as t}from"../chunks/entry.CzKU0Ip0.js";export{t as start};
