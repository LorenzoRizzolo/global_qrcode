import{a as t}from"../chunks/entry.BOyijsxE.js";export{t as start};
