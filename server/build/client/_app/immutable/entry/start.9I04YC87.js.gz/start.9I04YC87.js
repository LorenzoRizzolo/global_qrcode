import{a as t}from"../chunks/entry.CDPnbf-K.js";export{t as start};
