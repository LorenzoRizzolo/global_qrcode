import{a as t}from"../chunks/entry.D0Rzf-12.js";export{t as start};
