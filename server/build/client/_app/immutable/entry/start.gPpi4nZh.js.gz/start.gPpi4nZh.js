import{a as t}from"../chunks/entry.CON_CRJ7.js";export{t as start};
