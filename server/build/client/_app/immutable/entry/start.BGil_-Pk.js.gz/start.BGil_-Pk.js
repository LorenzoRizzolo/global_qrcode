import{a as t}from"../chunks/entry.D-lEvJ0o.js";export{t as start};
