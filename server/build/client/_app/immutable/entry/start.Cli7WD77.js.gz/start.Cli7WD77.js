import{a as t}from"../chunks/entry.DWTf4CAy.js";export{t as start};
