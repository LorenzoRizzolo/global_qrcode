import{a as t}from"../chunks/entry.e7CTr6zr.js";export{t as start};
