import{a as t}from"../chunks/entry.ZxL-nXae.js";export{t as start};
