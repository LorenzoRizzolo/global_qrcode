import{a as t}from"../chunks/entry.DKRz3bzJ.js";export{t as start};
